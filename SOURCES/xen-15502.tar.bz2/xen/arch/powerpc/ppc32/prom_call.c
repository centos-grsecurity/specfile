/*
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 * Copyright (C) IBM Corp. 2005
 *
 * Authors: Jimi Xenidis <jimix@watson.ibm.com>
 */

#include <xen/config.h>
#include <xen/types.h>
#include <asm/processor.h>

typedef s32 (*prom_call_t)(void *, ulong);

s32
prom_call(void *arg, uval base, uval func, uval msr __attribute__ ((unused)))
{
    prom_call_t f = (prom_call_t)func;
    ulong srr0 = mfsrr0();
    ulong srr1 = mfsrr1();
    s32 ret;

    ret = f(arg, base);

    mtsrr0(srr0);
    mtsrr1(srr1);

    return ret;
}
