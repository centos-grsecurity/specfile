#include "../x86/numa.c"
